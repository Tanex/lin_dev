// ------------------------------------------
// File a.h
// ------------------------------------------

extern int addering(int*, std::string);
extern std::string* adressbuss(int*, std::string);
extern int* adressering(int, std::string*);
extern int* advent(int, std::string*);
extern int* aftonsol(int, std::string*);
extern int aha(int*, std::string);
extern int* aj(int, std::string*);
extern std::string al(int, std::string*);
extern int aldrig(int*, std::string);
extern std::string* alfa(int*, std::string);
extern int* algebra(int, std::string*);
extern std::string alias(int, std::string*);
extern std::string alika(int, std::string*);
