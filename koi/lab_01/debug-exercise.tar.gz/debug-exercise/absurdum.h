// ------------------------------------------
// File absurdum.h
// ------------------------------------------

extern std::string amortering(int, std::string*);
extern std::string* ampere(int*, std::string);
extern int* ana(int, std::string*);
extern int* ande(int, std::string*);
extern int andel(int*, std::string);
extern std::string* angivning(int*, std::string);
extern int* anhopning(int, std::string*);
extern int aning(int*, std::string);
extern int anknytning(int*, std::string);
extern std::string* anledning(int*, std::string);
extern std::string anm(int, std::string*);
extern std::string anmaning(int, std::string*);
extern int* ann(int, std::string*);
