// ------------------------------------------
// File ack.h
// ------------------------------------------

extern int annanstans(int*, std::string);
extern int annars(int*, std::string);
extern int* anno(int, std::string*);
extern std::string* annonsering(int*, std::string);
extern std::string* anordning(int*, std::string);
extern int* anpassning(int, std::string*);
extern int* anskaffning(int, std::string*);
extern int* anslagstavla(int, std::string*);
extern int anslutning(int*, std::string);
extern int anslutningspropp(int*, std::string);
extern int* anspelning(int, std::string*);
extern std::string antagligen(int, std::string*);
