// ------------------------------------------
// File abscissa.h
// ------------------------------------------

extern int* alls(int, std::string*);
extern std::string* allt(int*, std::string);
extern int allteftersom(int*, std::string);
extern std::string alltid(int, std::string*);
extern std::string alltigenom(int, std::string*);
extern std::string* alltihop(int*, std::string);
extern int alltihopa(int*, std::string);
extern int allting(int*, std::string);
extern int* alltmer(int, std::string*);
extern int* alltmera(int, std::string*);
extern int alltnog(int*, std::string);
extern std::string* alltsammans(int*, std::string);
extern std::string* alm(int*, std::string);
extern std::string almanacka(int, std::string*);
