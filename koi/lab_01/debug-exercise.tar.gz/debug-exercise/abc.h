// ------------------------------------------
// File abc.h
// ------------------------------------------

extern int* allafall(int, std::string*);
extern std::string* allah(int*, std::string);
extern int* alldeles(int, std::string*);
extern std::string* allehanda(int*, std::string);
extern int allena(int*, std::string);
extern int allesammans(int*, std::string);
extern int allihop(int*, std::string);
extern int* allmoge(int, std::string*);
extern int* allokering(int, std::string*);
extern int* allra(int, std::string*);
