/* main.c */

#include "global.h"

int main(void)
{
  init();
  parse();
  exit(0);    /*  successful termination  */
}
